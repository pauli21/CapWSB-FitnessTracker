/*
 * Copyright (c) 2023, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/**
 * <h2>Provides interfaces describing classfile constant pool entries for the {@link java.lang.classfile} library.</h2>
 *
 * The {@code java.lang.classfile.constantpool} package contains interfaces describing classfile constant pool entries.
 *
 * @since 22
 */
@PreviewFeature(feature = PreviewFeature.Feature.CLASSFILE_API)
package java.lang.classfile.constantpool;

import jdk.internal.javac.PreviewFeature;
